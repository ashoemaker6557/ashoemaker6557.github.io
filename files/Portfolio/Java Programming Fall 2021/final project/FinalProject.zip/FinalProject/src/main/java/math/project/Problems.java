/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author aaash
 */
package math.project;

public class Problems {
    String prompt;
    int answer;
    double divAnswer;
   
   public Problems(String prompt, int answer){
       this.prompt = prompt;
       this.answer = answer;
   }
}
